<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Formulario de Registro</title>
</head>
<body>
    <h2>Formulario de Registro</h2>
    <form action="proceso.php" method="POST">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required><br><br>
        
        <label for="curso">Curso:</label>
        <input type="text" id="curso" name="curso" required><br><br>
        
        <label for="edad">Edad:</label>
        <input type="number" id="edad" name="edad" required><br><br>
        
        <label for="sena">¿Está en el Sena?:</label>
        <input type="checkbox" id="sena" name="sena"><br><br>
        
        <label for="adso">¿Está en Adso?:</label>
        <input type="checkbox" id="adso" name="adso"><br><br>
        
        <input type="submit" value="Enviar">
    </form>
</body>
</html>
