<?php

$dbhost = 'localhost';
$dbname = 'ejercicio_matricula';
$dbuser = 'root';
$dbpass = '';


try {
    $conn = new PDO('mysql:host=' .$dbhost. ';dbname=' .$dbname. ';charset=utf8' , $dbuser, $dbpass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    die("Error al conectar a la base de datos: " . $e->getMessage());
}

?>