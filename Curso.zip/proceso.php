<?php
include_once 'conect.php';
include_once 'fun.php';


$nombre = $_POST['nombre'];
$nombre_curso = $_POST['curso'];
$edad = $_POST['edad'];
$sena = isset($_POST['sena']);
$adso = isset($_POST['adso']);


guardarEnBaseDeDatos($nombre, $nombre_curso, $edad, $sena, $adso);



$edadDB = obtenerEdadDesdeBD($edad); 
$senaDB = obtenerSenaDesdeBD($sena); 
$adsoDB = obtenerAdsoDesdeBD($adso);
$precioDB = obtenerPrecioDesdeBD($nombre_curso);

$descuento = 0.25;

if ($senaDB) {
    $descuento = 0.35;

    
    if ($adsoDB) {
        $descuento += 0.15;
}
}

if ($edadDB >= 16 && $edadDB < 20) {
    $descuento += 0.15; 
} elseif ($edadDB >= 20 && $edadDB <= 25) {
    $descuento += 0.10; 
}

 


$precio = obtenerPrecioDesdeBD($nombre_curso);
$precioFinal = $precio - ($precio * $descuento);
$preciodes =($precio - $precioFinal);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Recibo</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .recibo {
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 300px;
        }

        h1 {
            text-align: center;
            margin-top: 0;
        }

        p {
            margin: 5px 0;
        }

        .recibo strong {
            font-weight: bold;
        }

        .recibo .label {
            font-weight: bold;
        }

        .recibo .valor {
            float: right;
        }
    </style>
</head>
<body>
    <div class="recibo">
        <h1>Recibo de Curso</h1>
        <p><span class="label">Nombre:</span> <span class="valor"><?php echo $nombre; ?></span></p>
        <p><span class="label">Curso:</span> <span class="valor"><?php echo $nombre_curso; ?></span></p>
        <p><span class="label">Descuento:</span> <span class="valor"><?php echo $descuento * 100; ?>%</span></p>
        <p><span class="label">Valor del curso:</span> <span class="valor">$<?php echo $precio; ?></span></p>
        <p><span class="label">Valor Descontado:</span> <span class="valor">$<?php echo $preciodes; ?></span></p>
        <p><span class="label">Valor con descuento:</span> <span class="valor">$<?php echo $precioFinal; ?></span></p>
    </div>
</body>
</html>