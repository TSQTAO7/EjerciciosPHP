<?php
require_once 'conect.php';


function guardarEnBaseDeDatos($nombre, $curso, $edad, $sena, $adso) {
    global $conn;

    try {
        $stmt = $conn->prepare("INSERT INTO estudiante (NOMBRE, EDAD, CURSO, INSTITUTO, ADSO) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute ([$nombre, $edad, $curso, $sena, $adso]);
    } catch (PDOException $e) {
        echo "Error al guardar los datos en la base de datos: " . $e->getMessage();
    }
}


function obtenerEdadDesdeBD($edad) {
    global $conn;

    try {
        $stmt = $conn->prepare("SELECT EDAD FROM estudiante WHERE EDAD=?");
        $stmt->execute([$edad]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['EDAD'];
    } catch (PDOException $e) {
        echo "Error al obtener la edad desde la base de datos: " . $e->getMessage();
    }
}

function obtenerPrecioDesdeBD($nombre_curso) {
    global $conn;

    try {
        $stmt = $conn->prepare("SELECT VALOR_CURSO FROM curso WHERE NOMBRE_CURSO = ?");
        $stmt->execute([$nombre_curso]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row !== false && isset($row['VALOR_CURSO'])) {
            return $row['VALOR_CURSO'];
        } else {
            return 0;
        }
    } catch (PDOException $e) {
        echo "Error al obtener el precio desde la base de datos: " . $e->getMessage();
    }
}


function obtenerSenaDesdeBD($sena) {
    global $conn;

    try {
        $stmt = $conn->prepare("SELECT INSTITUTO FROM estudiante WHERE INSTITUTO=?");
        $stmt->execute([$sena]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['INSTITUTO'] == 1;
    } catch (PDOException $e) {
        echo "Error al obtener el valor de Sena desde la base de datos: " . $e->getMessage();
    }
}

function obtenerAdsoDesdeBD($adso) {
    global $conn;

    try {
        $stmt = $conn->prepare("SELECT ADSO FROM ESTUDIANTE WHERE ADSO=?");
        $stmt->execute([$adso]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['ADSO'] == 1;
    } catch (PDOException $e) {
        echo "Error al obtener el valor de Adso desde la base de datos: " . $e->getMessage();
    }
}
?>