<?php
include_once 'conect.php';
include_once 'fun.php';
?>
<!DOCTYPE html>

<html>
<head>
    <title>Recibo</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .recibo {
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 300px;
        }

        h1 {
            text-align: center;
            margin-top: 0;
        }

        p {
            margin: 5px 0;
        }

        .recibo strong {
            font-weight: bold;
        }

        .recibo .label {
            font-weight: bold;
        }

        .recibo .valor {
            float: right;
        }
    </style>
</head>
<body>
    <div class="recibo">
        <h1>Recibo de Curso</h1>
        <p><span class="label">Nombre:</span> <span class="valor"><?php echo $nombre; ?></span></p>
        <p><span class="label">Curso:</span> <span class="valor"><?php echo $curso; ?></span></p>
        <p><span class="label">Descuento:</span> <span class="valor"><?php echo $descuento; ?>%</span></p>
        <p><span class="label">Valor del curso:</span> <span class="valor">$<?php echo $valorCurso; ?></span></p>
        <p><span class="label">Valor con descuento:</span> <span class="valor">$<?php echo $valorDescuento; ?></span></p>
    </div>
</body>
</html>